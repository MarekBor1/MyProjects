#ifndef NETSIM_PACKAGE_HPP
#define NETSIM_PACKAGE_HPP

class Package {
public:
    Package();

    Package(ElementID);

    Package(Package&&);

    operator=(Package&&) : Package&;

    get_id(): ElementID {query};

    ~Package();


};

#endif //NETSIM_PACKAGE_HPP
