#ifndef NETSIM_STORAGE_TYPES_HPP
#define NETSIM_STORAGE_TYPES_HPP

class PackageQueue {
public:
    PackageQueue(PackageQueueType);
};

enum class PackageQueue {
    FIFO, LIFO
};

<<interface>> IPackageQueue {
public:
    pop(): Package;
    get_queue_type(): PackageQueue {query};
};

<<interface>> IPackageStockpile {
public:
    push(Package&&): void;

    empty(): bool {query};

    size(): size_type {query}

    /iteratory???/

    ~IPackageStockpile()
};

#endif //NETSIM_STORAGE_TYPES_HPP
