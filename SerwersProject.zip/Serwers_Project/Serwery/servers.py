#!/usr/bin/python
# -*- coding: utf-8 -*-

from typing import Optional, TypeVar, List, Dict
from abc import ABC, abstractmethod
import re


class Product:

    def __init__(self, name: str, price: float):
        name_characters = list(name)
        print(name_characters)
        if not name_characters[0].isalpha():
            raise ValueError

        i = 0
        for char in name_characters:
            if char.isalnum() and not char.isalpha():
                i = 1
            if char.isalnum() and not char.isspace():
                continue
            else:
                raise ValueError

        if i == 0:
            raise ValueError


        self.name: str = name
        self.price: float = price

    def __eq__(self, other) -> bool:
        return hash(self) == hash(other)

    def __hash__(self):
        return hash((self.name, self.price))


class ServerError(Exception):
    pass


class TooManyProductsFoundError(ServerError):
    def __init__(self, popout=None):
        if popout is None:
            popout = "Too many products!"
        super().__init__()


class Server(ABC):
    n_max_returned_entries: int = 3

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def get_entries(self, n_letters: int = 1) -> List[Product]:
        pattern = f'^[a-zA-Z]{{{n_letters}}}\\d{{2,3}}$'
        entries = [product for product in self.get_products(n_letters)
                   if re.match(pattern, product.name)]
        if len(entries) > Server.n_max_returned_entries:
            raise TooManyProductsFoundError
        if entries:
            return sorted(entries, key=lambda product: product.price)
        return []

    @abstractmethod
    def get_products(self, n_letters: int = 1) -> List[Product]:
        return self.get_entries(n_letters)


class ListServer(Server):
    def __init__(self, products: List[Product], *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.products = products

    def get_products(self, n_letters: int = 1) -> List[Product]:
        return self.products


class MapServer(Server):
    def __init__(self, products: List[Product], *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.products: Dict[str, Product] = {
            product.name: product for product in products
        }

    def get_products(self, n_letters: int = 1) -> List[Product]:
        return list(self.products.values())



ServerType = TypeVar('ServerType', bound=Server)


class Client:


    def __init__(self, server: ServerType):
        self.server: ServerType = server

    def get_total_price(self, n_letters: Optional[int]) -> float:
        try:
            founded = self.server.get_entries(n_letters)
            price_sum = 0.0
            if founded:
                for product in founded:
                    price_sum += product.price
                return price_sum
            return None
        except TooManyProductsFoundError:
            return None

